package org.zerock.b01.repository.search;

import static org.junit.jupiter.api.Assertions.*;

class BoardSearchImplTest {

}